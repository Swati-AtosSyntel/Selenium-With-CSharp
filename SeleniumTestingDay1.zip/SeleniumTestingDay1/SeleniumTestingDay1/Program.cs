﻿using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SeleniumTestingDay1
{
    class Program
    {
        static void Main(string[] args)
        {
            IWebDriver driver = new FirefoxDriver();
            driver.Navigate().GoToUrl("https://www.google.com");
            //or
            //driver.Url = "https://www.googe.com";
            Console.WriteLine("Test Case Started");
            Thread.Sleep(2000);
            string title = driver.Title;
            Console.WriteLine("Title of Page:",title);
            string pagesource = driver.PageSource;
            Console.WriteLine(pagesource);
            Console.WriteLine(driver.Url);
            Console.WriteLine("-------------------");
            driver.Navigate().GoToUrl("https://www.calculator.net");
            Thread.Sleep(2000);
            title = driver.Title;
            Console.WriteLine("Title of Page:", title);
            Console.WriteLine(driver.Url);
            Console.WriteLine("-------------------");
            driver.Navigate().Back();
            Thread.Sleep(2000);
            Console.WriteLine("Call to Back Command");
            title = driver.Title;
            Console.WriteLine("Title of Page:", title);
            Console.WriteLine(driver.Url);
            Console.WriteLine("-------------------");
            driver.Navigate().Forward();
            Thread.Sleep(2000);
            Console.WriteLine("Call to forward Command");
            title = driver.Title;
            Console.WriteLine("Title of Page:", title);
            Console.WriteLine(driver.Url);
            Console.WriteLine("-------------------");
            driver.Navigate().GoToUrl("file:///D:/Swati/23-Mar%20To%2031-Mar/CEP/8.%20August-2020/Selenium%20with%20C%23-25-August/SeleniumTestingDay1/SeleniumTestingDay1/index.html");
            title = driver.Title;
            IWebElement e= driver.FindElement(By.TagName("h1"));
            string classname = e.GetAttribute("class");
            Console.WriteLine(classname);
            Console.WriteLine("Title of Page:", title);
            Console.WriteLine(driver.Url);
            Console.WriteLine("-------------------");
            driver.Close();
            Console.ReadLine();
        }
    }
}
