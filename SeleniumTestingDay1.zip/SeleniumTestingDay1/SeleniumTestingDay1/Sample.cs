﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SeleniumTestingDay1
{
    class Sample
    {
        IWebDriver driver;
        [SetUp]
        public void Initialize()
        {
            driver = new FirefoxDriver();
        }
        [Test]
        public void ExecuteTest()
        {
            driver.Url = "https://www.google.com";
            IWebElement element = driver.FindElement(By.Name("q"));
            Thread.Sleep(1000);
            element.SendKeys("C# Tutorial");
            Thread.Sleep(1000);
            element = driver.FindElement(By.Name("btnK"));
            Thread.Sleep(1000);
            element.Click();
            Thread.Sleep(1000);
        }

        [TearDown]
        public void EndTest()
        {
            driver.Close();
        }
    }
}
