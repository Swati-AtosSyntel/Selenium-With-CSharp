﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SeleniumDay3App
{
    class Program
    {
        IWebDriver driver;
        [SetUp]
        public void Initialize()
        {
            driver = new FirefoxDriver();
        }
        //[Test]
        public void SimpleAlert()
        {
            driver.Url = "file:///D:/Swati/23-Mar%20To%2031-Mar/CEP/8.%20August-2020/Selenium%20with%20C%23-25-August/SeleniumDay3App/SeleniumDay3App/index.html";
            driver.FindElement(By.TagName("button")).Click();
            Thread.Sleep(1000);
            IAlert simpleAlert = driver.SwitchTo().Alert();
            Console.WriteLine(simpleAlert.Text);
            simpleAlert.Accept();
        }
        //   [Test]
        public void HandleAlert()
        {
            driver.Navigate().GoToUrl("http://demo.guru99.com/test/delete_customer.php");
            Thread.Sleep(2000);
            driver.FindElement(By.Name("cusid")).SendKeys("53920");
            Thread.Sleep(1000);
            driver.FindElement(By.Name("submit")).Submit();

            IAlert alert = driver.SwitchTo().Alert();
            // Capturing alert message.    
            string alertMessage = driver.SwitchTo().Alert().Text;
            Console.WriteLine(alertMessage);
            Thread.Sleep(4000);
            //alert.Accept();
            alert.Dismiss();

        }
        //[Test]
        public void PromptAlert()
        {
            driver.Navigate().GoToUrl("file:///D:/Swati/23-Mar%20To%2031-Mar/CEP/8.%20August-2020/Selenium%20with%20C%23-25-August/SeleniumDay3App/SeleniumDay3App/index.html");
            driver.Manage().Window.Maximize();
            Thread.Sleep(2000);
            driver.FindElement(By.TagName("button")).Click();
            Thread.Sleep(3000);
            IAlert alert = driver.SwitchTo().Alert();

            Thread.Sleep(2000);
            alert.SendKeys("23");
            Thread.Sleep(1000);
            alert.Accept();
            Console.WriteLine("Alert Accepted");

        }
       // [Test]
        public void HandleMultipleWindows()
        {

            driver.Url = "https://www.demoqa.com/browser-windows";
            Thread.Sleep(2000);
            string mainWindow = driver.CurrentWindowHandle;
            for (int i = 0; i < 3; i++)
            {
                driver.FindElement(By.Id("windowButton")).Click();
                Thread.Sleep(2000);
                Console.WriteLine(driver.Url);

            }
            IList<string> windows = driver.WindowHandles.ToList();
            foreach (var handle in windows)
            {
                driver.SwitchTo().Window(handle);
                Console.WriteLine(handle);
            }
            driver.SwitchTo().Window(mainWindow);
            Thread.Sleep(2000);
        }
       // [Test]
        public void HandleModal()
        {
            //driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
           // driver.Manage().Timeouts().AsynchronousJavaScript = TimeSpan.FromSeconds(30);
            driver.Url = "https://www.w3schools.com/howto/howto_css_login_form.asp";
            Thread.Sleep(3000);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

            driver.FindElement(By.XPath("//*[@id='main']/button")).Click();
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("//*[@id='id01']/div/div[2]/div/input[1]")).SendKeys("Swati");
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//*[@id='id01']/div/div[2]/div/input[2]")).SendKeys("Swati@123");
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//*[@id='id01']/div/div[2]/div/button")).Click();
            Thread.Sleep(2000);
            // IAlert alert = driver.SwitchTo().Alert();
            //driver.FindElement(By.CssSelector("input.w3-input:nth-child(2)")).SendKeys("swati");
        }
      // [Test]
        public void Multipletabs()
        {
            string test_url = "http://the-internet.herokuapp.com/windows";

            OpenQA.Selenium.Support.UI.WebDriverWait wait = new OpenQA.Selenium.Support.UI.WebDriverWait(driver, TimeSpan.FromSeconds(10));

            driver.Url = test_url;
            var mainWindow = driver.CurrentWindowHandle;
            var browser_button = driver.FindElement(By.XPath("//a[.='Click Here']"));
            Assert.AreEqual(1, driver.WindowHandles.Count);

            string WindowTitle = "The Internet";
            Assert.AreEqual(WindowTitle, driver.Title);
            Console.WriteLine(driver.Title);
            driver.SwitchTo().Window(mainWindow);
            Thread.Sleep(1000);

            browser_button.Click();
            Assert.AreEqual(2, driver.WindowHandles.Count);
            Console.WriteLine("Window Handle[0] - " + driver.WindowHandles[0]);

            var newTabHandle = driver.WindowHandles[1];
            //Assert.IsTrue(!string.IsNullOrEmpty(newTabHandle));

            Console.WriteLine("Window Handle[1] - " + driver.WindowHandles[1]);

           // Assert.AreEqual(driver.SwitchTo().Window(newTabHandle).Url, "http://the-internet.herokuapp.com/windows/new");

            string expectedNewWindowTitle = "New Window";
            //Assert.AreEqual(driver.SwitchTo().Window(newTabHandle).Title, expectedNewWindowTitle);
            /* Thread Sleep is not a good practice since it is a blocking call */
            /* Only used for demonstration */
            System.Threading.Thread.Sleep(2000);
            Console.WriteLine(expectedNewWindowTitle);
            driver.SwitchTo().Window(driver.WindowHandles[1]).Close();
            driver.SwitchTo().Window(driver.WindowHandles[0]);

            System.Threading.Thread.Sleep(2000);
        }
        [Test]
        public void ExplicitWaitExample()
        {
            driver.Url = "file:///D:/Swati/23-Mar%20To%2031-Mar/CEP/8.%20August-2020/Selenium%20with%20C%23-25-August/SeleniumDay3App/SeleniumDay3App/abc.html";
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromMinutes(1));
            Func<IWebDriver, bool> waitForElement = new Func<IWebDriver, bool>
                ((IWebDriver Web) =>
                {
                    Console.WriteLine("Waiting for color to change");
                    IWebElement element = Web.FindElement(By.Id("target"));
                    if (element.GetAttribute("style").Contains("red"))
                    {
                        return true; ;
                    }
                    return false;
                });
            Console.WriteLine(wait.Until(waitForElement));

        }
        [Test]
        public void DefaultWait()
        {
            driver.Url = "file:///D:/Swati/23-Mar%20To%2031-Mar/CEP/8.%20August-2020/Selenium%20with%20C%23/SeleniumDay5/SeleniumDay5/abc.html";
            IWebElement element = driver.FindElement(By.Id("target"));
            DefaultWait<IWebElement> wait = new DefaultWait<IWebElement>(element);
            wait.Timeout = TimeSpan.FromMinutes(2);
            wait.PollingInterval = TimeSpan.FromMilliseconds(250);
            Func<IWebElement, bool> wait1 = new Func<IWebElement, bool>((IWebElement e) =>

               {
                   string styleAttribute = element.GetAttribute("style");
                   if (styleAttribute.Contains("red"))
                   {
                       return true;
                   }
                   Console.WriteLine("Color is still" + styleAttribute);
                   return false;
               });
            wait.Until(wait1);
        }

        [TearDown]
        public void EndTest()
        {
            driver.Close();
        }
        static void Main(string[] args)
        {


        }
    }
}
