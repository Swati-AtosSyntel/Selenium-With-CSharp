﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SeleniumDemo1
{
    class Program
    {
        IWebDriver driver;
        [SetUp]
        public void Initialize()
        {
            driver = new FirefoxDriver();
            Console.WriteLine("Test Case Started");
        }

        [Test]
        public void ExecuteTest()
        {
            driver.Navigate().GoToUrl("https://www.google.co.in");
            Thread.Sleep(2000);
        
        IWebElement searchTxt = driver.FindElement(By.Name("q"));
            Thread.Sleep(1000);
            searchTxt.SendKeys("C# Tutorial");
            IWebElement searchBtn = driver.FindElement(By.Name("btnK"));
            Thread.Sleep(2000);
            searchBtn.Click();
            Thread.Sleep(2000);
        }
           [TearDown] 
        public void EndTest()
        {
            driver.Close();
            Console.WriteLine("Test Case Ended");
        }
          
            //get reference of SearchTextBox on Google Search Page
            
           // [Test]
        public void Ex1()
        {
            driver = new FirefoxDriver();
            Console.WriteLine("Test Case Started");
            driver.Navigate().GoToUrl("https://www.google.co.in");
            Thread.Sleep(1000);
            driver.Manage().Window.Maximize();
            Console.WriteLine("Current Url:"+driver.Url);
            driver.Navigate().GoToUrl("http://www.calculator.net");
            Console.WriteLine("Now The URl is :"+driver.Url);
            driver.Navigate().Back();
            Console.WriteLine("After going Back:"+driver.Url);
            driver.Navigate().Forward();
            Console.WriteLine("After going forward:" + driver.Url);
            driver.Close();
        }
        public void Ex2()
        {
            driver = new FirefoxDriver();
            Console.WriteLine("Test Case Started");
            //driver.Navigate().GoToUrl("file:///D:/Swati/23-Mar%20To%2031-Mar/August-2020/Selenium%20with%20C%23/05-Aug/SeleniumDemo1/SeleniumDemo1/index.html");
          
            driver.Manage().Window.Maximize();
            Console.WriteLine("Test Case Started");
            //IWebElement e = driver.FindElement(By.LinkText("Click Here for Google"));
            //e = driver.FindElement(By.PartialLinkText("FaceBook"));
            //e.Click();
            IWebElement parent = driver.FindElement(By.TagName("div"));
            IWebElement rb = parent.FindElement(By.Id("r2"));
            rb.Click();
            driver.Quit();
        }
        public void Ex3()
        {
            driver = new FirefoxDriver();
            Console.WriteLine("Test Case Started");
            driver.Navigate().GoToUrl("file:///D:/Swati/23-Mar%20To%2031-Mar/August-2020/Selenium%20with%20C%23/05-Aug/SeleniumDemo1/SeleniumDemo1/index.html");
            driver.Manage().Window.Maximize();
           
            IList<IWebElement> rbs = driver.FindElements(By.Name("gender"));
            Thread.Sleep(2000);
            rbs.ElementAt(0).Click();
            Thread.Sleep(2000);
            bool result = false;
            result = rbs.ElementAt(0).Selected;
            if(result==true)
            {
                rbs.ElementAt(1).Click();
                Console.WriteLine(rbs.ElementAt(1).GetAttribute("Text"));
                Thread.Sleep(2000);
            }
           else
            {
                rbs.ElementAt(0).Click();
                Console.WriteLine(rbs.ElementAt(0).GetAttribute("Text"));
            }
            Thread.Sleep(1000);
            driver.Quit();
        }
        
        static void Main(string[] args)
        {
            Program p = new Program();
            //p.Ex1();
            //p.Ex2();
            // p.Ex3();
           p.driver = new FirefoxDriver();
            Console.WriteLine("Test Case Started");
            p.driver.Navigate().GoToUrl("https://www.calculator.net");
            p.driver.Manage().Window.Maximize();
            
            IWebElement e = p.driver.FindElement(By.LinkText("Loan Calculator"));
            e.Click();
            Console.ReadLine();
        }
    }
}
